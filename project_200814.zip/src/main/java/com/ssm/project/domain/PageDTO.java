package com.ssm.project.domain;

import lombok.Data;

@Data
public class PageDTO {
	
	private int page;
	private int limit;

}