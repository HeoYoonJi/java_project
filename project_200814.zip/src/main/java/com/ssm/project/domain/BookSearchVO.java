package com.ssm.project.domain;

import lombok.Data;

@Data
public class BookSearchVO {
	
	private String searchKind;
	private String searchWord;

}