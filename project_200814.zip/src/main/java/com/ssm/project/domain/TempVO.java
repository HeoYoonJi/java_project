package com.ssm.project.domain;

import java.util.Date;

import lombok.Data;

@Data
public class TempVO {

	private Date birthday;
}
