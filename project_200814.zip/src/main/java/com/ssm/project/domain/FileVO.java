package com.ssm.project.domain;

import lombok.Data;

@Data
public class FileVO {
	
	private String fileName;
	private String msg;

}