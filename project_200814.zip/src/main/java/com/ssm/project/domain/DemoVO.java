package com.ssm.project.domain;

public class DemoVO {

	private String visit1;

	public String getVisit1() {
		return visit1;
	}

	public void setVisit1(String visit1) {
		this.visit1 = visit1;
	}
	
}
