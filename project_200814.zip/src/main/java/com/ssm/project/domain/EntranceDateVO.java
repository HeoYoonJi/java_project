package com.ssm.project.domain;

import java.util.Date;

import lombok.Data;

@Data
public class EntranceDateVO {
	
	private Date entranceDate;
	private String entranceTimeBand;
}
