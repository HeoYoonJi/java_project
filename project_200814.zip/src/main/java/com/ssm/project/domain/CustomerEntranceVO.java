package com.ssm.project.domain;

import java.util.Date;

import lombok.Data;

@Data
public class CustomerEntranceVO {
	
	private int id;
	private Date entranceDate;
	private String entranceTimeBand;
	private String visit1;
	private String visit2;
	private String visit3;
	private String visit4;
	private String visit5;
	private String visit6;
	private String visit7;
	private String visit8;
	private String visit9;
	private String visit10;
	private String visit11;
	private String visit12;
	private String visit13;
	private String visit14;
	private String visit15;
	private String visit16;
	private String visit17;
	
}
