select id, genre from book_tbl
order by id;
